import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import axios from "axios";
import "./style.css";
const API = "http://127.0.0.1:5002";

function App() {
 const [rules,setRules]=useState([]), [alerts,setAlerts]=useState([]), [stats,setStats]=useState({});
 const [events,setEvents]=useState([]), [error,setError]=useState(""), [notice,setNotice]=useState("");
 const [rule,setRule]=useState({name:"",source_ip:"*",port:"22",protocol:"TCP",action:"BLOCK"});
 const [traffic,setTraffic]=useState({source_ip:"192.168.1.10",destination_ip:"192.168.1.20",port:"22",protocol:"TCP",kind:"SSH_FAILED"});
 const [bastion,setBastion]=useState("192.168.1.10");

 async function refresh(){
  try {
   const [r,a,s]=await Promise.all([axios.get(`${API}/api/rules`),axios.get(`${API}/api/alerts`),axios.get(`${API}/api/stats`)]);
   setRules(r.data);setAlerts(a.data);setStats(s.data);setError("");
  } catch {setError("Backend not connected. Start Sentinel/backend with: py app.py");}
 }
 useEffect(()=>{refresh();const t=setInterval(refresh,3000);return ()=>clearInterval(t);},[]);
 async function addRule(e){
  e.preventDefault();try{await axios.post(`${API}/api/rules`,rule);setRule({name:"",source_ip:"*",port:"22",protocol:"TCP",action:"BLOCK"});setNotice("Firewall rule added.");refresh();}
  catch(err){setError(err.response?.data?.error||"Could not add rule.");}
 }
 async function removeRule(id){try{await axios.delete(`${API}/api/rules/${id}`);refresh();}catch{setError("Could not delete rule.");}}
 async function sendTraffic(e){
  e.preventDefault();try{const r=await axios.post(`${API}/api/traffic`,{...traffic,port:Number(traffic.port)});setEvents(old=>[r.data.event,...old].slice(0,25));setNotice(`Traffic processed: ${r.data.event.firewall_action}`);refresh();}
  catch(err){setError(err.response?.data?.error||"Could not simulate traffic.");}
 }
 async function reset(){try{await axios.post(`${API}/api/reset`);setEvents([]);setNotice("Traffic and alerts cleared.");refresh();}catch{setError("Reset failed.");}}
 return <main>
  <header><div className="eyebrow">ALM PROJECT 3</div><h1>Sentinel</h1><p>Intrusion detection and firewall simulator</p><span className="pill">SIMULATED NETWORK · SAFE LEARNING ENVIRONMENT</span></header>
  <section className="stats">
   <div><span>Traffic events</span><b>{stats.simulated_events??0}</b></div><div><span>Active rules</span><b>{stats.rules??0}</b></div><div><span>Blocked</span><b>{stats.blocked??0}</b></div><div><span>Alerts</span><b>{stats.alerts??0}</b></div>
  </section>
  <section className="panel"><h2>Firewall Rule Manager</h2><p className="muted">Rules are checked from top to bottom. The first matching rule is applied.</p>
   <form className="rule-form" onSubmit={addRule}>
    <label>Rule name<input value={rule.name} onChange={e=>setRule({...rule,name:e.target.value})} placeholder="e.g. Block SSH" required/></label>
    <label>Source IP<input value={rule.source_ip} onChange={e=>setRule({...rule,source_ip:e.target.value})} placeholder="* or 192.168.1.10" required/></label>
    <label>Port<input value={rule.port} onChange={e=>setRule({...rule,port:e.target.value})} placeholder="22 or *" required/></label>
    <label>Protocol<select value={rule.protocol} onChange={e=>setRule({...rule,protocol:e.target.value})}><option>TCP</option><option>UDP</option><option>ANY</option></select></label>
    <label>Action<select value={rule.action} onChange={e=>setRule({...rule,action:e.target.value})}><option>BLOCK</option><option>ALLOW</option></select></label>
    <button className="primary">Add Rule</button>
   </form>
   <div className="table-wrap"><table><thead><tr><th>Name</th><th>Source</th><th>Port</th><th>Protocol</th><th>Action</th><th></th></tr></thead><tbody>{rules.map(r=><tr key={r.id}><td>{r.name}</td><td>{r.source_ip}</td><td>{r.port}</td><td>{r.protocol}</td><td><span className={r.action==="BLOCK"?"blocked":"allowed"}>{r.action}</span></td><td><button className="small" onClick={()=>removeRule(r.id)}>Delete</button></td></tr>)}</tbody></table></div>
  </section>
  <section className="panel"><h2>Traffic Generator</h2><p className="muted">Generate sample events to test firewall and IDS rules. Nothing is sent over the network.</p>
   <form className="traffic-form" onSubmit={sendTraffic}>
    <label>Source IP<input value={traffic.source_ip} onChange={e=>setTraffic({...traffic,source_ip:e.target.value})}/></label>
    <label>Destination IP<input value={traffic.destination_ip} onChange={e=>setTraffic({...traffic,destination_ip:e.target.value})}/></label>
    <label>Port<input type="number" min="1" max="65535" value={traffic.port} onChange={e=>setTraffic({...traffic,port:e.target.value})}/></label>
    <label>Protocol<select value={traffic.protocol} onChange={e=>setTraffic({...traffic,protocol:e.target.value})}><option>TCP</option><option>UDP</option></select></label>
    <label>Event type<select value={traffic.kind} onChange={e=>setTraffic({...traffic,kind:e.target.value})}><option>HTTP</option><option>SSH</option><option>SSH_FAILED</option><option>PORT_SCAN</option><option>DNS</option><option>OTHER</option></select></label>
    <button className="primary">Simulate Traffic</button>
   </form>
   <div className="quick"><button onClick={()=>setTraffic({...traffic,port:"23",protocol:"TCP",kind:"OTHER"})}>Try suspicious Telnet (23)</button><button onClick={()=>setTraffic({...traffic,port:"22",protocol:"TCP",kind:"SSH_FAILED"})}>Try failed SSH login</button><button className="secondary" onClick={reset}>Clear traffic & alerts</button></div>
   {notice&&<p className="notice">{notice}</p>}
  </section>
  <section className="panel"><h2>IDS Alert Feed <span className="live">LIVE REFRESH</span></h2>{alerts.length===0?<p className="muted">No alerts yet. Try simulating Telnet traffic or several failed SSH logins.</p>:alerts.map(a=><article className="alert" key={a.id}><div><b>{a.kind}</b><span className={a.severity==="HIGH"?"severity-high":"severity-medium"}>{a.severity}</span><p>{a.message}</p><small>{a.time} · Source {a.source_ip}</small></div></article>)}</section>
  <section className="panel"><h2>Recent Simulated Traffic</h2>{events.length===0?<p className="muted">Your generated traffic appears here.</p>:<div className="table-wrap"><table><thead><tr><th>Time</th><th>Source</th><th>Destination</th><th>Port</th><th>Type</th><th>Decision</th></tr></thead><tbody>{events.map((e,i)=><tr key={i}><td>{e.time}</td><td>{e.source_ip}</td><td>{e.destination_ip}</td><td>{e.port}</td><td>{e.kind}</td><td><span className={e.firewall_action==="BLOCK"?"blocked":"allowed"}>{e.firewall_action}</span></td></tr>)}</tbody></table></div>}</section>
  <section className="panel"><h2>Bastion Host (Concept)</h2><p>A bastion host is a hardened system that acts as a controlled gateway to a protected network. In this demo, choose an example IP to label it.</p><label className="bastion-label">Bastion host IP<input value={bastion} onChange={e=>setBastion(e.target.value)}/></label><div className="bastion">Internet <span>→</span> Firewall <span>→</span> <strong>{bastion||"Bastion host"}</strong> <span>→</span> Private Network</div></section>
  <section className="panel"><h2>Threat Encyclopedia</h2><div className="threats"><article><h3>Virus</h3><p>Malicious code that attaches to a file or program and typically needs user action to spread. Use updated security software and avoid untrusted attachments.</p></article><article><h3>Worm</h3><p>Malware that can self-propagate across systems or networks. Patch systems, segment networks, and monitor unusual traffic.</p></article><article><h3>Rule-based IDS</h3><p>Matches events against known patterns, such as repeated failed SSH logins or suspicious Telnet activity.</p></article><article><h3>Anomaly-based IDS</h3><p>Looks for unusual behavior compared with a baseline. This demo uses a simple event-rate threshold as an illustration.</p></article></div></section>
  {error&&<div className="error">{error}</div>}<footer>Educational simulation only. Does not inspect or block real network traffic.</footer>
 </main>
}
createRoot(document.getElementById("root")).render(<App/>);
