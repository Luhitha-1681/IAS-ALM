SENTINEL — RUN INSTRUCTIONS (Windows)
Requirements: Python and Node.js installed.

BACKEND
1. Open the Sentinel/backend folder in File Explorer.
2. Click the address bar, type powershell, and press Enter.
3. Run:
   py -m pip install -r requirements.txt
   py app.py
4. Leave this terminal open. API: http://127.0.0.1:5002

FRONTEND
1. Open a SECOND PowerShell terminal in Sentinel/frontend.
2. Run:
   npm install
   npm run dev
3. Open the local URL shown by Vite (usually http://127.0.0.1:5173).

Try the default firewall rules, add your own rule, then generate Telnet traffic on port 23
or click "Try failed SSH login" five times to trigger an IDS alert.

Everything is simulated. The app does not send, inspect, or block real network packets.
