SENTINEL BACKEND
1. Open PowerShell in this backend folder.
2. Run: py -m pip install -r requirements.txt
3. Run: py app.py
4. API runs at http://127.0.0.1:5002

Traffic is simulated in the application; no actual network packets are sent.
