from flask import Flask, jsonify, request
from flask_cors import CORS
from collections import defaultdict, deque
from datetime import datetime, timezone
import statistics
import threading

app = Flask(__name__)
CORS(app)

rules = [
    {"id": 1, "name": "Block Telnet", "source_ip": "*", "port": "23", "protocol": "TCP", "action": "BLOCK"},
    {"id": 2, "name": "Allow HTTP", "source_ip": "*", "port": "80", "protocol": "TCP", "action": "ALLOW"},
]
alerts = []
events = []
failed_logins = defaultdict(deque)
packet_rates = defaultdict(deque)
next_rule_id = 3
next_alert_id = 1
lock = threading.Lock()

def add_alert(kind, severity, message, source_ip):
    global next_alert_id
    with lock:
        item = {"id": next_alert_id, "time": datetime.now(timezone.utc).astimezone().strftime("%H:%M:%S"),
                "kind": kind, "severity": severity, "message": message, "source_ip": source_ip}
        next_alert_id += 1
        alerts.insert(0, item)
        del alerts[100:]
    return item

@app.get("/")
def home():
    return jsonify({"app":"Sentinel IDS & Firewall Simulator","note":"All traffic is simulated; no real packets are sent.","endpoints":["/api/rules","/api/traffic","/api/alerts","/api/stats"]})

@app.get("/api/rules")
def get_rules():
    return jsonify(rules)

@app.post("/api/rules")
def add_rule():
    global next_rule_id
    data = request.get_json(silent=True) or {}
    required = ["name", "source_ip", "port", "protocol", "action"]
    if any(not str(data.get(k, "")).strip() for k in required):
        return jsonify({"error":"Fill in name, source IP, port, protocol, and action."}), 400
    if str(data["action"]).upper() not in ("ALLOW", "BLOCK"):
        return jsonify({"error":"Action must be ALLOW or BLOCK."}), 400
    if str(data["protocol"]).upper() not in ("TCP", "UDP", "ANY"):
        return jsonify({"error":"Protocol must be TCP, UDP, or ANY."}), 400
    try:
        port = int(data["port"])
        if not 1 <= port <= 65535: raise ValueError()
    except ValueError:
        if str(data["port"]) != "*":
            return jsonify({"error":"Port must be * or a number from 1 to 65535."}), 400
    rule = {"id":next_rule_id, "name":str(data["name"]), "source_ip":str(data["source_ip"]),
            "port":str(data["port"]), "protocol":str(data["protocol"]).upper(), "action":str(data["action"]).upper()}
    next_rule_id += 1
    rules.append(rule)
    return jsonify(rule), 201

@app.delete("/api/rules/<int:rule_id>")
def delete_rule(rule_id):
    global rules
    old = len(rules)
    rules = [r for r in rules if r["id"] != rule_id]
    if len(rules) == old:
        return jsonify({"error":"Rule not found"}), 404
    return jsonify({"deleted":rule_id})

@app.get("/api/alerts")
def get_alerts():
    return jsonify(alerts)

@app.get("/api/stats")
def stats():
    return jsonify({"simulated_events":len(events),"alerts":len(alerts),"rules":len(rules),
                    "blocked":sum(1 for e in events if e["firewall_action"]=="BLOCK"),
                    "allowed":sum(1 for e in events if e["firewall_action"]=="ALLOW")})

@app.post("/api/traffic")
def traffic():
    data = request.get_json(silent=True) or {}
    source = str(data.get("source_ip","192.168.1.10"))
    dest = str(data.get("destination_ip","192.168.1.20"))
    try: port = int(data.get("port",80))
    except (ValueError, TypeError): return jsonify({"error":"Port must be a number."}), 400
    proto = str(data.get("protocol","TCP")).upper()
    kind = str(data.get("kind","HTTP")).upper()
    outcome = "ALLOW"
    matched = None
    for rule in rules:
        if (rule["source_ip"] in ("*", source) and rule["port"] in ("*", str(port))
            and rule["protocol"] in ("ANY", proto)):
            matched = rule
            outcome = rule["action"]
            break

    event = {"time":datetime.now(timezone.utc).astimezone().strftime("%H:%M:%S"),
             "source_ip":source,"destination_ip":dest,"port":port,"protocol":proto,"kind":kind,
             "firewall_action":outcome,"matched_rule":matched["name"] if matched else "Default allow"}
    events.insert(0,event)
    del events[200:]

    if port == 23:
        add_alert("Rule-based IDS","HIGH",f"Suspicious Telnet traffic detected on port 23 from {source}.",source)
    if kind in ("SSH_FAILED","FAILED_LOGIN"):
        now = datetime.now().timestamp()
        q = failed_logins[source]
        q.append(now)
        while q and now-q[0] > 60: q.popleft()
        if len(q) >= 5:
            add_alert("Rule-based IDS","HIGH",f"{len(q)} failed SSH logins within 1 minute from {source}.",source)
    # A deliberately simple rate anomaly model for demonstration.
    q = packet_rates[source]
    now = datetime.now().timestamp()
    q.append(now)
    while q and now-q[0] > 10: q.popleft()
    if len(q) >= 10:
        add_alert("Statistical anomaly","MEDIUM",f"Unusually high simulated traffic rate from {source} ({len(q)} events / 10 sec).",source)
        q.clear()
    if outcome == "BLOCK":
        add_alert("Firewall","MEDIUM",f"Traffic blocked by rule '{matched['name']}'.",source)
    return jsonify({"event":event,"alerts":alerts[:5]})

@app.post("/api/reset")
def reset():
    events.clear(); alerts.clear(); failed_logins.clear(); packet_rates.clear()
    return jsonify({"message":"Traffic and alerts reset. Firewall rules retained."})

if __name__ == "__main__":
    app.run(debug=True, port=5002)
