import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import axios from "axios";
import "./style.css";

const API = "http://127.0.0.1:5001";
function App() {
  const [protocol, setProtocol] = useState("tls");
  const [sid, setSid] = useState("");
  const [step, setStep] = useState(0);
  const [total, setTotal] = useState(6);
  const [log, setLog] = useState([]);
  const [ipsecMode, setIpsecMode] = useState("transport");
  const [packet, setPacket] = useState(null);
  const [error, setError] = useState("");

  async function start(p = protocol) {
    try {
      setError(""); setLog([]); setStep(0); setPacket(null);
      const r = await axios.post(`${API}/api/${p}/start`);
      setSid(r.data.session_id); setTotal(r.data.total_steps);
      setProtocol(p); setLog([{title:`${p.toUpperCase()} Simulation Started`, description:r.data.message}]);
    } catch { setError("Cannot connect to backend. Start backend using: py app.py"); }
  }
  async function next() {
    try {
      setError("");
      const r = await axios.post(`${API}/api/${protocol}/next`, {session_id:sid});
      if (r.data.title) { setLog(old => [...old, r.data]); setStep(r.data.step); }
      else setError(r.data.message || r.data.error || "No step returned");
    } catch { setError("Start a new simulation, and check that the backend is running."); }
  }
  async function showIpsec() {
    try { const r = await axios.post(`${API}/api/ipsec`, {mode:ipsecMode}); setPacket(r.data); setError(""); }
    catch { setError("Cannot connect to backend. Start backend using: py app.py"); }
  }
  return <main>
    <header><div className="eyebrow">ALM PROJECT 2</div><h1>SecureTunnel</h1><p>Explore how secure connections are established.</p></header>
    <section className="panel">
      <h2>Handshake Visualizer</h2>
      <div className="tabs">
        <button className={protocol==="tls"?"active":""} onClick={()=>start("tls")}>TLS Handshake</button>
        <button className={protocol==="ssh"?"active":""} onClick={()=>start("ssh")}>SSH Connection</button>
      </div>
      <div className="parties"><div className="party"><span>CLIENT</span><b>{protocol==="tls"?"Browser":"SSH Client"}</b></div><div className="arrow">⇄</div><div className="party"><span>SERVER</span><b>{protocol==="tls"?"Web Server":"SSH Server"}</b></div></div>
      <div className="progress"><div style={{width:`${total ? step/total*100 : 0}%`}} /></div>
      <p className="muted">Step {step} of {total}</p>
      <button className="primary" onClick={next} disabled={!sid || step>=total}>Next Step →</button>
      <button className="secondary" onClick={()=>start(protocol)}>Restart</button>
      <div className="log">{log.length===0?<p className="muted">Choose TLS or SSH to begin the simulation.</p>:log.map((item,i)=><article key={i}><span className="step-tag">{item.step?`STEP ${item.step}`:"READY"}</span><h3>{item.title}</h3><p>{item.description}</p>{item.session_key_demo&&<code>Demo session key: {item.session_key_demo}</code>}{item.note&&<p className="warning">{item.note}</p>}</article>)}</div>
    </section>
    <section className="panel">
      <h2>IPsec / ESP Packet View</h2><p className="muted">Compare how ESP works in transport and tunnel modes.</p>
      <div className="tabs"><button className={ipsecMode==="transport"?"active":""} onClick={()=>setIpsecMode("transport")}>Transport Mode</button><button className={ipsecMode==="tunnel"?"active":""} onClick={()=>setIpsecMode("tunnel")}>Tunnel Mode</button></div>
      <button className="primary" onClick={showIpsec}>Visualize Packet</button>
      {packet&&<div className="packet"><h3>{packet.mode}</h3><div className="packet-parts">{packet.packet.map((part,i)=><div key={i} className={part.toLowerCase().includes("encrypted")?"encrypted":part.includes("ESP")?"esp":""}>{part}</div>)}</div><p>{packet.explanation}</p></div>}
    </section>
    {error&&<div className="error">{error}</div>}
    <footer>Educational simulation only — not for real security or production use.</footer>
  </main>;
}
createRoot(document.getElementById("root")).render(<App />);
