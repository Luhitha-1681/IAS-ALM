from flask import Flask, jsonify, request
from flask_cors import CORS
import secrets
import hashlib
import base64

app = Flask(__name__)
CORS(app)

# Educational simulation only. This models the steps; it is NOT a real TLS/SSH implementation.
TLS_STEPS = [
    ("Client Hello", "The client sends supported protocol versions and cipher suites."),
    ("Server Hello + Certificate", "The server selects parameters and presents a demonstration certificate."),
    ("Certificate Verification", "The client checks the demo certificate status. Real systems validate certificate chains and hostnames."),
    ("Client Key Exchange", "A random pre-master secret is represented for teaching. Modern TLS normally uses ephemeral Diffie-Hellman, not RSA key transport."),
    ("Session Keys", "Client and server derive matching demonstration session keys from shared secret material."),
    ("Finished", "Both sides confirm that the handshake transcript agrees.")
]
SSH_STEPS = [
    ("Protocol Version Exchange", "Client and server announce compatible SSH protocol versions."),
    ("Key Exchange", "Both sides contribute values to a Diffie-Hellman-style shared-secret calculation."),
    ("Server Authentication", "The server proves possession of its host private key; the client checks its known-hosts record."),
    ("User Authentication", "The user is authenticated using a simulated password or public-key method."),
    ("Secure Channel Established", "Encryption and integrity protection are enabled for the session.")
]

def make_state(protocol):
    secret = secrets.token_hex(16)
    key = hashlib.sha256(secret.encode()).hexdigest()
    return {
        "protocol": protocol,
        "id": secrets.token_hex(8),
        "step": 0,
        "shared_secret_demo": secret,
        "session_key_demo": key,
        "authenticated": False
    }

sessions = {}

@app.get("/")
def home():
    return jsonify({
        "app": "SecureTunnel API",
        "note": "Educational simulation only; not a production TLS/SSH implementation.",
        "endpoints": ["/api/tls/start", "/api/tls/next", "/api/ssh/start", "/api/ssh/next", "/api/ipsec"]
    })

@app.post("/api/<protocol>/start")
def start(protocol):
    protocol = protocol.lower()
    if protocol not in ("tls", "ssh"):
        return jsonify({"error": "Protocol must be tls or ssh"}), 400
    state = make_state(protocol)
    sessions[state["id"]] = state
    steps = TLS_STEPS if protocol == "tls" else SSH_STEPS
    return jsonify({
        "session_id": state["id"],
        "protocol": protocol.upper(),
        "total_steps": len(steps),
        "current_step": 0,
        "message": "Simulation started. Click Next Step to continue."
    })

@app.post("/api/<protocol>/next")
def next_step(protocol):
    data = request.get_json(silent=True) or {}
    sid = data.get("session_id")
    state = sessions.get(sid)
    if not state or state["protocol"] != protocol.lower():
        return jsonify({"error": "Invalid session_id. Start a new simulation first."}), 400

    steps = TLS_STEPS if protocol.lower() == "tls" else SSH_STEPS
    if state["step"] >= len(steps):
        return jsonify({"done": True, "message": "Simulation already complete.", "step": state["step"]})

    title, description = steps[state["step"]]
    current = state["step"] + 1
    state["step"] = current
    result = {
        "step": current,
        "total_steps": len(steps),
        "title": title,
        "description": description,
        "done": current == len(steps)
    }
    if protocol.lower() == "tls" and title == "Session Keys":
        result["session_key_demo"] = state["session_key_demo"]
        result["note"] = "Demonstration key only; do not use for real communication."
    if protocol.lower() == "ssh" and title == "User Authentication":
        state["authenticated"] = True
        result["authentication"] = "Simulated authentication successful"
    return jsonify(result)

@app.post("/api/ipsec")
def ipsec():
    data = request.get_json(silent=True) or {}
    mode = data.get("mode", "transport").lower()
    if mode not in ("transport", "tunnel"):
        return jsonify({"error": "mode must be transport or tunnel"}), 400
    if mode == "transport":
        return jsonify({
            "mode": "Transport Mode",
            "packet": ["Original IP Header", "ESP Header", "Encrypted TCP/UDP + Payload", "ESP Trailer", "ESP Authentication Data"],
            "explanation": "Transport mode protects the IP payload while retaining the original IP header."
        })
    return jsonify({
        "mode": "Tunnel Mode",
        "packet": ["New Outer IP Header", "ESP Header", "Encrypted Original IP Header + Payload", "ESP Trailer", "ESP Authentication Data"],
        "explanation": "Tunnel mode protects the complete original IP packet inside a new outer IP packet."
    })

if __name__ == "__main__":
    app.run(debug=True, port=5001)
