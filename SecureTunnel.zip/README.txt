SECURETUNNEL — RUN INSTRUCTIONS (Windows)
Requirements: Python and Node.js installed.

BACKEND
1. Open the SecureTunnel/backend folder in File Explorer.
2. Click the address bar, type powershell, and press Enter.
3. Run:
   py -m pip install -r requirements.txt
   py app.py
4. Leave this terminal open. API: http://127.0.0.1:5001

FRONTEND
1. Open a SECOND PowerShell terminal in SecureTunnel/frontend.
2. Run:
   npm install
   npm run dev
3. Open the local URL shown by Vite (usually http://127.0.0.1:5173).

If the frontend says it cannot connect, make sure the backend terminal is still running.

Educational simulation only. This project does not implement production TLS/SSH.
